// Materia: Programación I, Paralelo 1
// Autor: W. Gardenia Choque Cruz
// Fecha creación: 15/10/2024
// Número de ejercicio: 5
// Problema planteado:Escribe un programa que cuente cuántas palabras hay en una oración.

#include <iostream>
#include <string>
using namespace std;

int contarTerminos(const string& oracion)
{
    int total = 0;
    bool dentroTermino = false;
    for (char letra : oracion) {
        if (letra != ' ' && !dentroTermino) 
        {
            total++;
            dentroTermino = true;
        } else if (letra == ' ') {
            dentroTermino = false;
        }
    }
    return total;
}

int main()
{
    string oracion;
    
    cout << "Escribe una oracion";
    getline(cin, oracion);
    
    cout << "Numero de terminos" << contarTerminos(oracion) << endl;

    return 0;
}