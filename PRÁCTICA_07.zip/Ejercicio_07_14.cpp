// Materia: Programación I, Paralelo 1
// Autor: W. Gardenia Choque Cruz
// Fecha creación: 16/10/2024
// Número de ejercicio: 14
// Problema planteado:Escribe un programa que encuentre y muestre la palabra más larga en una oración.
#include <iostream>
#include <string>

using namespace std;

string encontrarPalabraMasLarga(const string& oracion) 
{
    string palabraMasLarga, palabraActual;
    size_t longitudPalabra = 0;

    for (char c : oracion) 
    {
        if (c == ' ') 
        {
            if (palabraActual.length() > palabraMasLarga.length()) 
            {
                palabraMasLarga = palabraActual;
            }
            palabraActual = "";  // Reiniciar la palabra actual
        } 
        else 
        {
            palabraActual += c;
        }
    }

    // Comparar la última palabra después del bucle
    if (palabraActual.length() > palabraMasLarga.length()) 
    {
        palabraMasLarga = palabraActual;
    }

    return palabraMasLarga;
}

int main() 
{
    string oracion;

    cout << "Ingresa una oracion: ";
    getline(cin, oracion);
    
    cout << "Palabra más larga: " << encontrarPalabraMasLarga(oracion) << endl;

    return 0;
}
