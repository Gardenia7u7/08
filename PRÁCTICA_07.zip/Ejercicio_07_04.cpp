// Materia: Programación I, Paralelo 1
// Autor: W. Gardenia Choque Cruz
// Fecha creación: 15/10/2024
// Número de ejercicio: 4
// Problema planteado: Escribe un programa que compare dos cadenas e imprima si son iguales o
//diferentes, sin importar las mayúsculas o minúsculas.

#include <iostream>
#include <string>
#include <algorithm>

using namespace std;

string aMinusculas(const string& oracion) {
    string textoModificado = oracion;
    transform(textoModificado.begin(), textoModificado.end(), textoModificado.begin(), ::tolower);
    return textoModificado;
}

bool sonIguales(const string& oracion1, const string& oracion2) {
    return aMinusculas(oracion1) == aMinusculas(oracion2);
}

int main() {
    string oracion1, oracion2;
    
    cout << "Ingresa la primera oracion";
    getline(cin, oracion1);
    
    cout << "Ingresa la segunda oracion";
    getline(cin, oracion2);
    
    if (sonIguales(oracion1, oracion2)) {
        cout << "Las oraciones son iguales" << endl;
    } else {
        cout << "Las oraciones son diferentes" << endl;
    }

    return 0;
}