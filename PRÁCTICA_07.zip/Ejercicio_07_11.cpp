// Materia: Programación I, Paralelo 1
// Autor: W. Gardenia Choque Cruz
// Fecha creación: 16/10/2024
// Número de ejercicio: 11
// Problema planteado: Eliminar todos los dígitos de una cadena

#include <iostream>
#include <string>

using namespace std;

string eliminarDigitos(const string& oracion) 
{
    string sinNumeros;
    for (char caracter : oracion)
    {
        if (!isdigit(caracter)) 
        {
            sinNumeros += caracter;
        }
    }
    return sinNumeros;
}

int main() 
{
    string oracion;
    
    cout << "Ingresa una oracion: ";
    getline(cin, oracion);
    
    cout << "Oracion sin numeros: " << eliminarDigitos(oracion) << endl;

    return 0;
}
