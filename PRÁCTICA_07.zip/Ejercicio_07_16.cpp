// Materia: Programación I, Paralelo 1
// Autor: W. Gardenia Choque Cruz
// Fecha creación: 16/10/2024
// Número de ejercicio: 16
// Problema planteado: Programa que valide si una expresión matemática tiene los
// paréntesis balanceados correctamente.

#include <iostream>
#include <string>
#include <stack>

using namespace std;

bool estanBalanceados(const string& expresion)
{
    stack<char> pila;

    for (char c : expresion)
    {
        if (c == '(' || c == '{' || c == '[')
        {
            pila.push(c);
        }
        else if (c == ')' || c == '}' || c == ']')
        {
            if (pila.empty()) return false;
            char cima = pila.top();
            if ((c == ')' && cima != '(') ||
                (c == '}' && cima != '{') ||
                (c == ']' && cima != '['))
            {
                return false;
            }
            pila.pop();
        }
    }

    return pila.empty();
}

int main()
{
    string expresion;

    cout << "Ingresa una expresion matematica: ";
    getline(cin, expresion);

    if (estanBalanceados(expresion))
    {
        cout << "CORRECTO" << endl;
    }
    else
    {
        cout << "NO BALANCEADOS" << endl;
    }

    return 0;
}
