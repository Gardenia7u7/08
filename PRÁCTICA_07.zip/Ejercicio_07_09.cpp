// Materia: Programación I, Paralelo 1
// Autor: W. Gardenia Choque Cruz
// Fecha creación: 15/10/2024
// Numero de ejercicio: 9
// Problema planteado:Escribe un programa que "comprima" una cadena de caracteres, es decir,
//que agrupe caracteres consecutivos y cuente su frecuencia.

#include <iostream>
#include <string>
using namespace std;

string reducirCadena(const string& oracion) 
{
    string textoComprimido;
    int cuenta = 1;

    for (size_t i = 1; i <= oracion.length(); i++) {
        if (i < oracion.length() && oracion[i] == oracion[i - 1])
        {
            cuenta++;
        } else {
            textoComprimido += oracion[i - 1];
            textoComprimido += to_string(cuenta);
            cuenta = 1;
        }
    }

    return textoComprimido;
}

int main() {
    string oracion;
    
    cout << "Escribe una oracion: ";
    getline(cin, oracion);
    
    cout << "Oracion comprimida: " << reducirCadena(oracion) << endl;

    return 0;
}