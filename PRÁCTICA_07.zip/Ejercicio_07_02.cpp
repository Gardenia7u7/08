// Materia: Programación I, Paralelo 1
// Autor: W. Gardenia Choque Cruz
// Fecha creación: 15/10/2024
// Número de ejercicio: 2
// Problema planteado:Escribe un programa que cuente el número de vocales 

#include <iostream>
#include <string>

using namespace std;

int enumerarVocales(const string& oracion) {
    int totalVocales = 0;
    for (char letra : oracion) {
        switch (tolower(letra)) {
            case 'a': case 'e': case 'i': case 'o': case 'u':
                totalVocales++;
                break;
        }
    }
    return totalVocales;
}

int main() {
    string oracion;
    
    cout << "Ingresa una oracion";
    getline(cin, oracion);
    
    cout << "Numero de vocales " << enumerarVocales(oracion) << endl;

    return 0;
}