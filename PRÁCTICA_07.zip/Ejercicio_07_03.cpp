// Materia: Programación I, Paralelo 1
// Autor: W. Gardenia Choque Cruz
// Fecha creación: 15/10/2024
// Número de ejercicio: 3
// Problema planteado: Escribe un programa que elimine todos los espacios de una cadena.

#include <iostream>
#include <string>

using namespace std;

string quitarBlancos(const string& oracion) {
    string sinEspacios;
    for (char letra : oracion) {
        if (letra != ' ') {
            sinEspacios += letra;
        }
    }
    return sinEspacios;
}

int main() {
    string oracion;
    
    cout << "Escribe una oracion";
    getline(cin, oracion);
    
    cout << "Oracion sin espacios" << quitarBlancos(oracion) << endl;

    return 0;
}