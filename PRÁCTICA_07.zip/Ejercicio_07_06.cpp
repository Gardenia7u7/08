// Materia: Programación I, Paralelo 1
// Autor: W. Gardenia Choque Cruz
// Fecha creación: 15/10/2024
// Número de ejercicio: 6
// Problema planteado:Escribe un programa que determine si una cadena es un palíndromo (se lee
//igual de izquierda a derecha que de derecha a izquierda).


#include <iostream>
#include <string>
using namespace std;

bool verificarPalindromo(const string& oracion)
{
    return equal(oracion.begin(), oracion.begin() + oracion.size() / 2, oracion.rbegin());
}

int main() 
{
    string oracion;
    
    cout << "Escribe una oracion";
    getline(cin, oracion);
    
    cout << (verificarPalindromo(oracion) ? "Es un palindromo" : "No es un palindromo") << endl;

    return 0;
}