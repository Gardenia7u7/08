// Materia: Programación I, Paralelo 1
// Autor: W. Gardenia Choque Cruz
// Fecha creación: 15/10/2024
// Número de ejercicio: 1
// Problema planteado: Escribe un programa que tome una cadena de entrada y la invierta.

#include <iostream>
#include <string>
using namespace std;

string funcionInvertida(const string& oracion) 
{
    return string(oracion.rbegin(), oracion.rend());
}

int main() {
    string oracion;
    
    cout << "Ingresa una oracion";
    getline(cin, oracion);
    
    string oracionInvertida = funcionInvertida(oracion);
    
    cout << "Frase invertida" << oracionInvertida << endl;

    return 0;
}