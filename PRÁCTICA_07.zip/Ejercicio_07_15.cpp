// Materia: Programación I, Paralelo 1
// Autor: W. Gardenia Choque Cruz
// Fecha creación: 16/10/2024
// Número de ejercicio: 15
// Problema planteado: programa que valide si una cadena ingresada cumple con el
// formato básico de una dirección de correo electrónico

#include <iostream>
#include <string>

using namespace std;

bool esCorreoValido(const string& correo) 
{
    size_t posicionArroba = correo.find('@');
    size_t posicionPunto = correo.find('.', posicionArroba);

    return posicionArroba != string::npos && 
           posicionPunto != string::npos && 
           posicionPunto > posicionArroba + 1 && 
           posicionArroba > 0 && 
           posicionArroba < correo.length() - 1;
}

int main() 
{
    string correo;

    cout << "Ingresa un correo electronico: ";
    getline(cin, correo);
    
    if (esCorreoValido(correo)) 
    {
        cout << "Correo electronico valido" << endl;
    } else {
        cout << "Correo electronico invalido" << endl;
    }

    return 0;
}
