// Materia: Programación I, Paralelo 1
// Autor: W. Gardenia Choque Cruz
// Fecha creación: 16/10/2024
// Número de ejercicio: 13
// Problema planteado:Invierta el orden de las palabras de una oracion cambiar el orden de los caracteres dentro de cada palabra.

#include <iostream>
#include <string>
#include <vector>

using namespace std;

void invertirOrdenPalabras(const string& frase) 
{
    vector<string> palabras;
    string palabraActual;

    for (char c : frase) 
    {
        if (c == ' ') 
        {
            if (!palabraActual.empty()) 
            {
                palabras.push_back(palabraActual);
                palabraActual = "";  // Reiniciar la palabra actual
            }
        } 
        else 
        {
            palabraActual += c;
        }
    }

    // Añadir la última palabra
    if (!palabraActual.empty()) 
    {
        palabras.push_back(palabraActual);
    }

    // Imprimir las palabras en orden inverso
    for (int i = palabras.size() - 1; i >= 0; i--) 
    {
        cout << palabras[i] << (i > 0 ? " " : "");
    }
    cout << endl;
}

int main()
{
    string frase;

    cout << "Ingresa una frase: ";
    getline(cin, frase);
    
    invertirOrdenPalabras(frase);

    return 0;
}
