// Materia: Programación I, Paralelo 1
// Autor: W. Gardenia Choque Cruz
// Fecha creación: 15/10/2024
// NÃºmero de ejercicio: 7
// Problema planteado:Escribe un programa que cuente la frecuencia de cada carÃ¡cter en una cadena.

#include <iostream>
#include <string>
#include <map>
using namespace std;

map<char, int> calcularFrecuencia(const string& oracion) 
{
    map<char, int> conteo;
    for (char letra : oracion)
    {
        conteo[letra]++;
    }
    return conteo;
}

int main()
{
    string oracion;
    
    cout << "Escribe una oracion";
    getline(cin, oracion);
    
    map<char, int> conteo = calcularFrecuencia(oracion);
    
    for (const auto& elemento : conteo)
    {
        cout << elemento.first << ": " << elemento.second << endl;
    }

    return 0;
}