// Materia: Programación I, Paralelo 1
// Autor: W. Gardenia Choque Cruz
// Fecha creación: 16/10/2024
// Número de ejercicio: 13
// Problema planteado:Programa que divida la cadena en tokens

#include <iostream>
#include <string>

using namespace std;

void dividirEnTokens(const string& frase, char delimitador) {
    string token;
    for (char c : frase) {
        if (c == delimitador) {
            cout << token << endl;
            token.clear();
        } else {
            token += c;
        }
    }
    cout << token << endl;
}

int main() {
    string frase;
    char delimitador;
    
    cout << "Ingresa una frase: ";
    getline(cin, frase);
    
    cout << "Ingresa el delimitador: ";
    cin >> delimitador;
    
    dividirEnTokens(frase, delimitador);

    return 0;
}
