// Materia: Programación I, Paralelo 1
// Autor: W. Gardenia Choque Cruz
// Fecha creación: 15/10/2024
// Número de ejercicio: 8
// Problema planteado:Escribe un programa que alterne entre mayúsculas y minúsculas en una cadena.

#include <iostream>
#include <string>
using namespace std;

string alternarLetras(const string& oracion)
{
    string textoModificado = oracion;
    for (size_t i = 0; i < oracion.length(); i++) 
    {
        if (i % 2 == 0) {
            textoModificado[i] = toupper(oracion[i]);
        } else {
            textoModificado[i] = tolower(oracion[i]);
        }
    }
    return textoModificado;
}

int main() 
{
    string oracion;
    
    cout << "Escribe una oracion";
    getline(cin, oracion);
    
    cout << "Oracion alternada: " << alternarLetras(oracion) << endl;

    return 0;
}