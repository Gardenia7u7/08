// Materia: Programación I, Paralelo 1
// Autor: W. Gardenia Choque Cruz
// Fecha creación: 15/10/2024
// Numero de ejercicio: 10
// Problema planteado:Escribe un programa que, dado el formato comprimido (del ejercicio 15),
//expanda la cadena al formato original.

#include <iostream>
#include <string>

using namespace std;

string descomprimirCadena(const string& compacta) {
    string textoExpandido;
    for (size_t i = 0; i < compacta.length(); i++) {
        char caracter = compacta[i];
        string digito;
        
        while (isdigit(compacta[i + 1])) {
            digito += compacta[++i];
        }

        int veces = stoi(digito);
        textoExpandido.append(veces, caracter);
    }

    return textoExpandido;
}

int main() 
{
    string compacta;
    
    cout << "Escribe la cadena comprimida: ";
    getline(cin, compacta);
    
    cout << "Cadena expandida: " << descomprimirCadena(compacta) << endl;

    return 0;
}